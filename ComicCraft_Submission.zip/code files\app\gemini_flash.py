import os
import json
import re
from dotenv import load_dotenv

load_dotenv()

def get_gemini_model():
    """Initializes and returns the Gemini Flash model if API key is configured."""
    api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    if not api_key or api_key.startswith("your_") or api_key == "":
        return None
    
    try:
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        # Try gemini-1.5-flash or gemini-2.0-flash
        try:
            return genai.GenerativeModel("models/gemini-1.5-flash")
        except Exception:
            return genai.GenerativeModel("gemini-1.5-flash")
    except Exception as e:
        print(f"Warning: Could not configure Gemini Flash: {e}")
        return None

def fallback_outline(user_prompt: str) -> list:
    """Generates an engaging, cohesive 5-panel comic outline when API is not available."""
    # Parse basic hints from user prompt
    prompt_lower = user_prompt.lower()
    
    # Extract character if mentioned
    character = "Hero"
    for word in ["fox", "knight", "detective", "astronaut", "wizard", "robot", "cat", "warrior", "scientist"]:
        if word in prompt_lower:
            character = word.capitalize()
            break
            
    return [
        {
            "panel": 1,
            "title": f"The Beginning: Dawn of the Journey",
            "scene_description": f"The protagonist sets out into the uncharted territory under a dramatic sky, preparing for what lies ahead.",
            "image_prompt": f"Dramatic wide shot of {user_prompt}, cinematic lighting, vibrant comic art style, highly detailed, expressive atmosphere"
        },
        {
            "panel": 2,
            "title": "The Discovery: An Unseen Mystery",
            "scene_description": f"Deeper into the environment, an unexpected artifact and mystical clues emerge from the shadows.",
            "image_prompt": f"Medium shot exploring mysterious glowing anomalies in the scene of {user_prompt}, intricate details, dynamic comic illustration"
        },
        {
            "panel": 3,
            "title": "The Confrontation: The Rising Challenge",
            "scene_description": f"Tension peaks as a formidable obstacle tests bravery, wit, and determination to the fullest.",
            "image_prompt": f"Intense action shot, high stakes confrontation in the world of {user_prompt}, dynamic angle, vivid colors, comic book style"
        },
        {
            "panel": 4,
            "title": "The Turning Point: A Spark of Brilliance",
            "scene_description": f"With quick thinking and decisive action, the turning point turns adversity into triumph.",
            "image_prompt": f"Heroic climax moment, brilliant energy flare and powerful decisive action, colorful graphic novel illustration"
        },
        {
            "panel": 5,
            "title": "The Aftermath: A New Legend Begins",
            "scene_description": f"Peace returns as our hero stands triumphant, looking toward future horizons with newfound wisdom.",
            "image_prompt": f"Serene golden hour vista, victorious and inspiring conclusion, masterwork comic art, beautiful composition"
        }
    ]

def generate_outline(user_prompt: str) -> list:
    """
    Generates a 5-panel comic layout based on the user's story prompt using Gemini.
    
    Args:
        user_prompt (str): The user's comic idea prompt.
        
    Returns:
        list: A list of dictionaries, one for each panel.
    """
    prompt = f"""
You are a professional AI comic planner.

Your task is to generate a strictly formatted JSON array containing 5 panel descriptions for a comic based on the story idea below:

STORY: "{user_prompt}"

Each JSON object must include:
- "panel": (integer from 1 to 5)
- "title": (string)
- "scene_description": (string)
- "image_prompt": (string describing the visual scene for image generation in comic art style)

Respond ONLY in this valid JSON format, without any explanations or markdown:
[
  {{
    "panel": 1,
    "title": "Title here",
    "scene_description": "Scene description here",
    "image_prompt": "Image prompt for Stable Diffusion"
  }}
]
"""
    model = get_gemini_model()
    if not model:
        print("[ComicCraft] Gemini API key not detected. Using intelligent fallback outline generator.")
        return fallback_outline(user_prompt)

    try:
        response = model.generate_content(prompt)
        output_text = response.text.strip()
        print("\n[RAW GEMINI RESPONSE]\n", output_text)

        # Remove markdown formatting if present
        if "```json" in output_text:
            output_text = output_text.split("```json")[1].split("```")[0].strip()
        elif "```" in output_text:
            output_text = output_text.split("```")[1].split("```")[0].strip()

        # Regex search for JSON array if extra text surrounds it
        match = re.search(r'\[\s*\{.*\}\s*\]', output_text, re.DOTALL)
        if match:
            output_text = match.group(0)

        panel_data = json.loads(output_text)

        # Structure validation
        if not isinstance(panel_data, list) or len(panel_data) == 0:
            raise ValueError("Gemini response is not a list.")

        for panel in panel_data:
            if not isinstance(panel, dict) or not all(key in panel for key in ("panel", "title", "scene_description", "image_prompt")):
                raise ValueError(f"Invalid panel format or missing keys: {panel}")

        return panel_data

    except json.JSONDecodeError as e:
        print(f"[X] JSON Decode Error: {e}")
        print(f"[X] Full Text Received:\n{output_text if 'output_text' in locals() else 'None'}")
        return fallback_outline(user_prompt)
    except Exception as e:
        print(f"[X] Unexpected Error in generate_outline: {e}")
        return fallback_outline(user_prompt)
