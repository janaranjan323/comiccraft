# ComicCraft - AI Comic Story Creator using Gemini Models

ComicCraft is a web-based application built with **FastAPI** that uses AI to generate personalized comic book stories and illustrations based on user-provided prompts. Powered by **Google's Gemini AI models** (`models/gemini-1.5-flash` for structured storyboards and `models/gemini-1.5-pro` for dialogues & narration) along with **Stable Diffusion / AI Image Synthesis**, ComicCraft streamlines the creative process of generating storylines, dialogues, and vivid comic-style imagery automatically.

---

## 🚀 Features

- **Personalized Comic Creation**: Specify story prompt, character name, setting, tone, and art style.
- **5-Panel Outline Generation**: Gemini Flash formats sequential panel descriptions and visual prompts.
- **Full Story & Dialogue Generation**: Gemini Pro pens dramatic character dialogues, narration, and atmospheric captions.
- **Comic Illustration Engine**: Generates panel illustrations matching your visual art style.
- **Interactive Web Preview**: Review your full comic sequentially with comic speech bubbles and captions.
- **Export to Multi-Page PDF**: Automatically compiles panels, illustrations, and narration into a timestamped printable PDF using FPDF.
- **RESTful API & Interactive Swagger UI**: Complete `/generate`, `/generate-comic/json`, `/test-image`, and `/export-success` endpoints.

---

## 📁 Project Structure

```
comiccraft/
├── app/
│   ├── __init__.py
│   ├── main.py              # FastAPI main application
│   ├── routes.py            # Route handlers & endpoints
│   ├── gemini_flash.py      # Panel outline generation (Gemini Flash)
│   ├── gemini_pro.py        # Narration & dialogue generation (Gemini Pro)
│   ├── image_generator.py   # Comic-style illustration generation
│   ├── layout_builder.py    # Assembles panels, stories & illustrations
│   └── exporters.py         # Multi-page PDF compiler via FPDF
├── templates/
│   ├── index.html           # Main creation form UI
│   ├── comic_preview.html   # Sequential comic reader & preview
│   └── export_success.html  # Download confirmation & CTA
├── static/
│   ├── css/
│   │   └── style.css        # Comic book design system & styles
│   ├── panels/              # Generated comic illustrations
│   ├── exports/             # Exported comic PDFs
│   └── fonts/               # PDF fonts
├── .env                     # Environment API keys
└── requirements.txt         # Python dependencies
```

---

## 🛠️ Setup & Installation

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure Environment Variables
Edit `.env`:
```env
GEMINI_API_KEY=your_gemini_api_key_here
HF_API_KEY=your_huggingface_api_key_here
```
*(Note: ComicCraft includes a high-fidelity local generation engine, ensuring seamless testing even when keys are not configured.)*

### 3. Run Application Server
```bash
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

### 4. Access the Application
- **Web Interface**: [http://127.0.0.1:8000](http://127.0.0.1:8000)
- **Interactive API Documentation (Swagger)**: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)
