import os
import sys
import json
import re
from dotenv import load_dotenv

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

def get_gemini_flash_model():
    """Initializes and returns the Gemini Flash model if API key is configured."""
    if not GEMINI_API_KEY or GEMINI_API_KEY == "your_gemini_api_key_here":
        return None
    try:
        import google.generativeai as genai
        genai.configure(api_key=GEMINI_API_KEY)
        return genai.GenerativeModel("gemini-1.5-flash")
    except Exception as e:
        print(f"[WARN] Error initializing Gemini Flash model: {e}")
        return None

def fallback_outline_generator(user_prompt: str) -> list:
    """Fallback generator to produce cohesive 5-panel outline if Gemini API is unreachable or not configured."""
    prompt_clean = user_prompt.replace("\n", " ").strip()
    return [
        {
            "panel": 1,
            "title": "The Journey Begins",
            "scene_description": f"Establishing scene for: {prompt_clean}. The atmosphere is charged with anticipation as the hero prepares for the quest.",
            "image_prompt": f"Comic book art, panel 1 opening scene of {prompt_clean}, cinematic lighting, vibrant comic art style, detailed character focus, dynamic angle"
        },
        {
            "panel": 2,
            "title": "Entering the Unknown",
            "scene_description": f"The character ventures deeper into uncharted territory, noticing mysterious signs and shifting environment.",
            "image_prompt": f"Comic book panel 2, deep exploration into {prompt_clean}, dramatic shadows, vivid colors, detailed background, bold ink lines"
        },
        {
            "panel": 3,
            "title": "The Rising Challenge",
            "scene_description": f"An unexpected obstacle or magical encounter suddenly appears, testing the character's courage and wits.",
            "image_prompt": f"Comic book panel 3, thrilling encounter during {prompt_clean}, action perspective, expressive character face, cinematic effects, comic styling"
        },
        {
            "panel": 4,
            "title": "The Turning Point",
            "scene_description": f"A moment of intense realization and heroic action as the character confronts the central challenge head on.",
            "image_prompt": f"Comic book panel 4, heroic climax moment of {prompt_clean}, glowing dynamic lighting, powerful posture, expressive motion lines, vibrant colors"
        },
        {
            "panel": 5,
            "title": "A New Horizon",
            "scene_description": f"Resolution and peaceful aftermath. The character reflects on the triumph with newfound wisdom and purpose.",
            "image_prompt": f"Comic book panel 5, serene triumphant conclusion of {prompt_clean}, golden hour light, breathtaking scenery, satisfied character smile, masterpiece comic style"
        }
    ]

def generate_outline(user_prompt: str) -> list:
    """
    Generates a 5-panel comic layout based on the user's story prompt using Gemini Flash.

    Args:
        user_prompt (str): The user's comic idea prompt.

    Returns:
        list: A list of dictionaries, one for each panel.
    """
    prompt = f"""You are a professional AI comic planner.

Your task is to generate a *strictly formatted* JSON array containing 5 panel descriptions for a comic based on the story idea below:

STORY: "{user_prompt}"

Each JSON object must include:
- "panel": (integer)
- "title": (string)
- "scene_description": (string)
- "image_prompt": (string)

Respond ONLY in this valid JSON format, without any explanations or markdown:
[
  {{
    "panel": 1,
    "title": "Title here",
    "scene_description": "Scene description here",
    "image_prompt": "Image prompt for Stable Diffusion"
  }},
  {{
    "panel": 2,
    "title": "Title here",
    "scene_description": "Scene description here",
    "image_prompt": "Image prompt for Stable Diffusion"
  }},
  {{
    "panel": 3,
    "title": "Title here",
    "scene_description": "Scene description here",
    "image_prompt": "Image prompt for Stable Diffusion"
  }},
  {{
    "panel": 4,
    "title": "Title here",
    "scene_description": "Scene description here",
    "image_prompt": "Image prompt for Stable Diffusion"
  }},
  {{
    "panel": 5,
    "title": "Title here",
    "scene_description": "Scene description here",
    "image_prompt": "Image prompt for Stable Diffusion"
  }}
]"""

    model = get_gemini_flash_model()
    if model is None:
        print("[INFO] Using built-in dynamic outline generator (Gemini API key not configured).")
        return fallback_outline_generator(user_prompt)

    try:
        response = model.generate_content(prompt)
        output_text = response.text.strip()

        # Remove any markdown formatting if present
        if output_text.startswith("```json"):
            output_text = output_text.replace("```json", "").replace("```", "").strip()
        elif output_text.startswith("```"):
            output_text = output_text.replace("```", "").strip()

        # Extract JSON array using regex if surrounded by other text
        json_match = re.search(r'\[\s*\{.*\}\s*\]', output_text, re.DOTALL)
        if json_match:
            output_text = json_match.group(0)

        panel_data = json.loads(output_text)

        # Additional structure validation
        if not isinstance(panel_data, list):
            raise ValueError("Gemini response is not a list.")

        for panel in panel_data:
            if not isinstance(panel, dict) or not all(key in panel for key in ("panel", "title", "scene_description", "image_prompt")):
                raise ValueError(f"Invalid panel format or missing keys: {panel}")

        return panel_data

    except json.JSONDecodeError as e:
        print(f"[ERROR] JSON Decode Error: {e}")
        return fallback_outline_generator(user_prompt)

    except Exception as e:
        print(f"[ERROR] Unexpected Error: {e}")
        return fallback_outline_generator(user_prompt)
