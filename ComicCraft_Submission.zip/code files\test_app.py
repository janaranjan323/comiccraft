import os
import sys

# Ensure UTF-8 output on Windows
if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8')

# Test imports
try:
    from app.gemini_flash import generate_outline
    from app.gemini_pro import generate_story
    from app.image_generator import generate_image
    from app.layout_builder import build_comic_layout
    from app.exporters import save_pdf
    print("[OK] All modules imported successfully.")
except Exception as e:
    print(f"[X] Import error: {e}")
    sys.exit(1)

# Test outline generation
print("\n--- Testing generate_outline ---")
prompt = "A brave fox exploring an enchanted forest."
outline = generate_outline(prompt)
print(f"Outline generated: {len(outline)} panels.")
for p in outline:
    print(f" - Panel {p['panel']}: {p['title']}")

# Test story generation
print("\n--- Testing generate_story ---")
story = generate_story(outline)
print("Story output preview:\n" + story[:200] + "...")

# Test image generation
print("\n--- Testing generate_image ---")
test_img_path = generate_image(outline[0]["image_prompt"], "test_panel_1.png")
print(f"Generated test image: {test_img_path} (exists: {os.path.exists(test_img_path)})")

# Test all panel images
images = [generate_image(p["image_prompt"]) for p in outline]
print(f"Generated {len(images)} images.")

# Test layout builder
print("\n--- Testing build_comic_layout ---")
layout = build_comic_layout(images, story, outline)
print(f"Layout built with {len(layout)} panels.")

# Test PDF exporter
print("\n--- Testing save_pdf ---")
pdf_path = save_pdf(layout)
print(f"PDF exported: {pdf_path} (exists: {os.path.exists(pdf_path)})")

print("\n[SUCCESS] ALL TESTS PASSED SUCCESSFULLY!")
