import os
import traceback
from typing import Optional
from fastapi import APIRouter, Request, Form, HTTPException, Query
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

from app.gemini_flash import generate_outline
from app.gemini_pro import generate_story
from app.image_generator import generate_image
from app.layout_builder import build_comic_layout
from app.exporters import save_pdf

router = APIRouter()
templates = Jinja2Templates(directory="templates")

class PromptRequest(BaseModel):
    prompt: str = Field(..., description="Main story prompt idea")
    character_name: Optional[str] = Field("Hero", description="Main character name")
    setting: Optional[str] = Field("Forest", description="Story setting / world")
    tone: Optional[str] = Field("Dramatic", description="Mood / tone")
    style: Optional[str] = Field("Comic Book", description="Visual art style")

@router.get("/", response_class=HTMLResponse)
async def home_page(request: Request):
    """Loads the ComicCraft homepage form."""
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={}
    )

@router.post("/generate", response_class=HTMLResponse)
async def generate_comic(
    request: Request,
    prompt: str = Form(..., description="Story prompt"),
    character_name: str = Form("Hero", description="Main character"),
    setting: str = Form("Forest", description="Setting"),
    tone: str = Form("Dramatic", description="Tone"),
    style: str = Form("Comic Book", description="Art Style")
):
    """
    Handles form submission, orchestrates AI generation pipeline,
    and returns the Comic Preview page.
    """
    try:
        # Combine user input into a single comprehensive prompt
        full_prompt = (
            f"{prompt}\n"
            f"The main character is {character_name}.\n"
            f"The setting is a {setting}.\n"
            f"The tone is {tone}. The art style is {style}."
        )

        # Step 1: Generate 5-panel comic outline
        outline = generate_outline(full_prompt)
        if not isinstance(outline, list) or not all("image_prompt" in panel for panel in outline):
            raise ValueError("Invalid outline structure from Gemini response.")

        # Step 2: Generate comic story narration and dialogue
        full_story = generate_story(outline)

        # Step 3: Generate images for each panel
        images = []
        for panel in outline:
            img_prompt = f"{panel.get('image_prompt', '')}, {style} style, vivid color"
            img_path = generate_image(img_prompt)
            images.append(img_path)

        # Step 4: Build cohesive comic layout
        layout = build_comic_layout(images, full_story, outline)

        # Step 5: Export to PDF
        pdf_path = save_pdf(layout)
        web_pdf_path = "/" + pdf_path.replace("\\", "/").lstrip("/")

        return templates.TemplateResponse(
            request=request,
            name="comic_preview.html",
            context={
                "layout": layout,
                "pdf_path": web_pdf_path,
                "prompt": prompt,
                "character_name": character_name,
                "setting": setting,
                "tone": tone,
                "style": style
            }
        )

    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/generate-comic/json")
async def generate_comic_json(payload: PromptRequest):
    """
    API endpoint accepting JSON payloads, triggers the full comic generation pipeline,
    and returns structured layout data and PDF path.
    """
    try:
        full_prompt = (
            f"{payload.prompt}\n"
            f"The main character is {payload.character_name}.\n"
            f"The setting is a {payload.setting}.\n"
            f"The tone is {payload.tone}. The art style is {payload.style}."
        )

        # Generate outline
        outline = generate_outline(full_prompt)
        # Generate story
        full_story = generate_story(outline)
        # Generate images
        images = [
            generate_image(f"{p.get('image_prompt', '')}, {payload.style} style") 
            for p in outline
        ]
        # Assemble layout
        layout = build_comic_layout(images, full_story, outline)
        # Export PDF
        pdf_path = save_pdf(layout)
        web_pdf_path = "/" + pdf_path.replace("\\", "/").lstrip("/")

        return JSONResponse(content={
            "status": "success",
            "metadata": {
                "character_name": payload.character_name,
                "setting": payload.setting,
                "tone": payload.tone,
                "style": payload.style
            },
            "layout": layout,
            "pdf_path": web_pdf_path,
            "full_story": full_story
        })

    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/export-success", response_class=HTMLResponse)
async def export_success(request: Request, pdf_path: str = Query(...)):
    """Renders the Comic Export Success confirmation page."""
    clean_pdf_path = "/" + pdf_path.replace("\\", "/").lstrip("/")
    return templates.TemplateResponse(
        request=request,
        name="export_success.html",
        context={
            "pdf_path": clean_pdf_path
        }
    )

@router.get("/download-file")
async def download_file(pdf_path: str = Query(...)):
    """Serves the generated comic PDF directly as a download attachment."""
    system_path = pdf_path.lstrip("/\\")
    if os.path.exists(system_path):
        filename = os.path.basename(system_path)
        return FileResponse(
            path=system_path,
            filename=filename,
            media_type="application/pdf"
        )
    raise HTTPException(status_code=404, detail="Requested PDF file not found.")

@router.get("/test-image")
async def test_image(prompt: str = "A futuristic city at sunset, sci-fi, cinematic, artstation"):
    """Developer utility endpoint to test image generation directly."""
    try:
        image_path = generate_image(prompt)
        return {
            "message": "Image generated successfully",
            "path": "/" + image_path.replace("\\", "/").lstrip("/")
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
