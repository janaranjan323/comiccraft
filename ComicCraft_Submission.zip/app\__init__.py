"""
ComicCraft - AI Comic Story Creator
Package initialization
"""
