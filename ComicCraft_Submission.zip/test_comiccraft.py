import os
import sys
import unittest
from fastapi.testclient import TestClient
from app.main import app
from app.gemini_flash import generate_outline
from app.gemini_pro import generate_story
from app.image_generator import generate_image
from app.layout_builder import build_comic_layout
from app.exporters import save_pdf

class TestComicCraft(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_01_gemini_flash_outline(self):
        prompt = "A brave fox exploring an enchanted forest"
        outline = generate_outline(prompt)
        self.assertIsInstance(outline, list)
        self.assertEqual(len(outline), 5)
        for panel in outline:
            self.assertIn("panel", panel)
            self.assertIn("title", panel)
            self.assertIn("scene_description", panel)
            self.assertIn("image_prompt", panel)
        print("Test 1 Passed: generate_outline produces 5 structured panels.")

    def test_02_gemini_pro_story(self):
        outline = [
            {"panel": 1, "title": "The Edge", "scene_description": "Fox standing at tree line", "image_prompt": "fox"},
            {"panel": 2, "title": "Deep Woods", "scene_description": "Fox finds glowing tree", "image_prompt": "woods"},
            {"panel": 3, "title": "The Crystal", "scene_description": "Fox reaches for crystal", "image_prompt": "crystal"},
            {"panel": 4, "title": "The Guardian", "scene_description": "Spirit owl appears", "image_prompt": "owl"},
            {"panel": 5, "title": "Friendship", "scene_description": "Fox and owl fly together", "image_prompt": "sky"}
        ]
        story = generate_story(outline)
        self.assertIsInstance(story, str)
        self.assertTrue(len(story) > 50)
        print("Test 2 Passed: generate_story produces rich narration & dialogue.")

    def test_03_image_generation(self):
        test_prompt = "Comic book test fox panel"
        img_path = generate_image(test_prompt)
        self.assertTrue(img_path.startswith("static/panels/"))
        self.assertTrue(os.path.exists(img_path))
        print(f"Test 3 Passed: generate_image created file at {img_path}.")

    def test_04_layout_builder_and_pdf_export(self):
        outline = [
            {"panel": 1, "title": "The Forest Edge", "scene_description": "Fox looking ahead", "image_prompt": "fox in forest"},
            {"panel": 2, "title": "Ancient Woods", "scene_description": "Bioluminescent mushrooms", "image_prompt": "forest lights"}
        ]
        img1 = generate_image("fox in forest test")
        img2 = generate_image("forest lights test")
        story = "**Panel 1: The Forest Edge**\n**CAPTION:** Night falls.\n**NARRATION:** Free leaps.\n\n**Panel 2: Ancient Woods**\n**CAPTION:** Glow.\n**NARRATION:** Paths open."
        
        layout = build_comic_layout([img1, img2], story, outline)
        self.assertEqual(len(layout), 2)
        self.assertEqual(layout[0]["image_path"], img1)
        
        pdf_path = save_pdf(layout)
        self.assertTrue(pdf_path.startswith("static/exports/"))
        self.assertTrue(os.path.exists(pdf_path))
        print(f"Test 4 Passed: build_comic_layout & save_pdf created PDF at {pdf_path}.")

    def test_05_fastapi_homepage(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("ComicCraft", response.text)
        print("Test 5 Passed: GET / returns homepage with 200 OK.")

    def test_06_fastapi_generate_form(self):
        form_data = {
            "prompt": "A brave fox in enchanted woods",
            "character_name": "Foxie",
            "setting": "Forest",
            "tone": "Dramatic",
            "style": "Anime"
        }
        response = self.client.post("/generate", data=form_data)
        self.assertEqual(response.status_code, 200)
        self.assertIn("Your Comic Preview", response.text)
        print("Test 6 Passed: POST /generate generates comic preview successfully.")

    def test_07_fastapi_json_endpoint(self):
        payload = {
            "prompt": "Cyberpunk detective solving a neon mystery",
            "character_name": "Vance",
            "setting": "Cyber City",
            "tone": "Mystery",
            "style": "Comic Book"
        }
        response = self.client.post("/generate-comic/json", json=payload)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["status"], "success")
        self.assertEqual(len(data["layout"]), 5)
        self.assertTrue(data["pdf_path"].endswith(".pdf"))
        print("Test 7 Passed: POST /generate-comic/json returns complete structured payload.")

    def test_08_export_success_route(self):
        response = self.client.get("/export-success?pdf_path=/static/exports/test.pdf")
        self.assertEqual(response.status_code, 200)
        self.assertIn("Comic Exported Successfully", response.text)
        print("Test 8 Passed: GET /export-success returns confirmation page.")

    def test_09_test_image_route(self):
        response = self.client.get("/test-image?prompt=A+magical+forest+glowing+blue")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["message"], "Image generated successfully")
        print("Test 9 Passed: GET /test-image endpoint functions correctly.")

if __name__ == "__main__":
    unittest.main()
