import os
from dotenv import load_dotenv

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

def get_gemini_pro_model():
    """Initializes and returns the Gemini Pro / 1.5 Flash model if API key is configured."""
    if not GEMINI_API_KEY or GEMINI_API_KEY == "your_gemini_api_key_here":
        return None
    try:
        import google.generativeai as genai
        genai.configure(api_key=GEMINI_API_KEY)
        try:
            return genai.GenerativeModel("gemini-1.5-pro")
        except Exception:
            return genai.GenerativeModel("gemini-1.5-flash")
    except Exception as e:
        print(f"[WARN] Error initializing Gemini Pro model: {e}")
        return None

def fallback_story_generator(outline: list) -> str:
    """Generates engaging comic narration and dialogues from outline if API is unavailable."""
    story_parts = []
    for i, panel in enumerate(outline, start=1):
        title = panel.get("title", f"Panel {i}")
        desc = panel.get("scene_description", "")
        
        part = f"""**Panel {i}: {title}**
**CAPTION:** {desc}
**NARRATION:** The wind carries a thrilling chill through the air. Every step echoes with purpose.
**DIALOGUE:** "We've made it this far--there's no turning back now!"
"""
        story_parts.append(part)
    return "\n\n".join(story_parts)

def generate_story(outline: list) -> str:
    """
    Generates a detailed comic story with narration and character dialogue
    from a list of comic panel outlines using Gemini 1.5 Pro.

    Args:
        outline (list): A list of dictionaries representing each comic panel's idea.

    Returns:
        str: The generated comic story text or formatted fallback.
    """
    formatted_outline = "\n".join([
        f"Panel {i+1}: {item.get('title', '')} - {item.get('scene_description', '')}" 
        for i, item in enumerate(outline)
    ])

    prompt = f"""You're a comic book writer.

Given the following panel breakdown, write a comic-style story with engaging narration and character dialogues for each panel.

Panel Outline:
{formatted_outline}

Guidelines:
- Use a fun and engaging tone, like an actual comic book.
- Clearly organize each section with **Panel X: Title** (e.g. **Panel 1: The Forest's Edge**).
- Include **CAPTION:** for ambient setting notes.
- Include **NARRATION:** and clearly marked character dialogue lines.
- Keep each panel self-contained but part of a cohesive story.
"""

    model = get_gemini_pro_model()
    if model is None:
        print("[INFO] Using built-in dynamic story generator (Gemini API key not configured).")
        return fallback_story_generator(outline)

    try:
        response = model.generate_content(prompt)
        if response and response.text:
            return response.text.strip()
        return fallback_story_generator(outline)
    except Exception as e:
        print(f"[ERROR] Error generating story from Gemini Pro: {e}")
        return fallback_story_generator(outline)
