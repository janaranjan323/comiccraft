import os
from dotenv import load_dotenv

load_dotenv()

def get_gemini_pro_model():
    """Initializes and returns the Gemini Pro model if API key is configured."""
    api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    if not api_key or api_key.startswith("your_") or api_key == "":
        return None
    
    try:
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        try:
            return genai.GenerativeModel("models/gemini-1.5-pro")
        except Exception:
            return genai.GenerativeModel("gemini-1.5-pro")
    except Exception as e:
        print(f"Warning: Could not configure Gemini Pro: {e}")
        return None

def fallback_story(outline: list) -> str:
    """Generates engaging comic narration and dialogue if Gemini API is unavailable."""
    sections = []
    for i, item in enumerate(outline, start=1):
        title = item.get("title", f"Scene {i}")
        desc = item.get("scene_description", "")
        
        section = (
            f"***Panel {i}: {title}***\n"
            f"**SCENE:** {desc}\n"
            f"**CAPTION:** The journey shifts into high gear as destiny unfolds before our eyes.\n"
            f"**NARRATION:** With steadfast resolve, every step forward turns hesitation into courage.\n"
            f"**DIALOGUE:** \"No turning back now... whatever lies beyond, we face it together!\""
        )
        sections.append(section)
    return "\n\n".join(sections)

def generate_story(outline: list) -> str:
    """
    Generates a detailed comic story with narration and character dialogue
    from a list of comic panel outlines using Gemini 1.5 Pro.
    
    Args:
        outline (list): A list of dictionaries/strings representing each comic panel's idea.
        
    Returns:
        str: The generated comic story text or an error message / fallback.
    """
    formatted_outline = "\n".join([
        f"{i}. Panel Title: {item.get('title', 'Panel ' + str(i))} | Scene: {item.get('scene_description', '')}"
        if isinstance(item, dict) else f"{i}. {item}"
        for i, item in enumerate(outline, start=1)
    ])

    prompt = f"""
You are an expert comic book writer.

Given the following panel breakdown, write an exhilarating comic-style story with engaging narration, environmental captions, and punchy character dialogues for each panel.

Panel Outline:
{formatted_outline}

Guidelines:
- Use a fun, vivid, and engaging tone, exactly like a real comic book.
- For each panel, format the header EXACTLY as:
***Panel X: Title of Panel***
- Below each panel header, include:
**CAPTION:** (A brief, atmospheric description of the ambient environment or sound effects like WHOOSH, CRACKLE, etc.)
**NARRATION:** (Rich descriptive text detailing the character's thoughts, emotions, and unfolding actions)
**DIALOGUE:** (Spoken dialogue in quotes with character names)
- Keep each panel self-contained but part of a continuous, cohesive story.
"""

    model = get_gemini_pro_model()
    if not model:
        print("[ComicCraft] Gemini API key not detected. Using intelligent fallback story generator.")
        return fallback_story(outline)

    try:
        response = model.generate_content(prompt)
        story_text = response.text.strip()
        print("\n[GEMINI PRO STORY GENERATED SUCCESSFULLY]")
        return story_text
    except Exception as e:
        print(f"[X] Error generating story: {e}")
        return fallback_story(outline)
