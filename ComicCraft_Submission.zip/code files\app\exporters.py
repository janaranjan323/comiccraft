import os
from datetime import datetime
from fpdf import FPDF

EXPORT_FOLDER = os.path.join("static", "exports")
os.makedirs(EXPORT_FOLDER, exist_ok=True)

class ComicPDF(FPDF):
    def header(self):
        # Comic header bar
        self.set_fill_color(30, 27, 75)
        self.rect(0, 0, self.w, 14, 'F')
        self.set_font("Helvetica", "B", 10)
        self.set_text_color(255, 255, 255)
        self.set_xy(10, 2)
        self.cell(self.w - 20, 10, "COMICCRAFT  -  AI COMIC CREATOR", align='C')
        self.ln(12)

    def footer(self):
        # Footer
        self.set_y(-15)
        self.set_font("Helvetica", "I", 8)
        self.set_text_color(128, 128, 128)
        self.cell(0, 10, f"Page {self.page_no()} | Generated with ComicCraft", align='C')

def clean_for_pdf(text: str) -> str:
    """Replaces unencodable characters with ascii safe equivalents."""
    replacements = {
        '“': '"', '”': '"', '‘': "'", '’': "'", '—': '-', '–': '-',
        '…': '...', '•': '*', '★': '*', '☆': '*', '•': '-', '™': '', '®': ''
    }
    for k, v in replacements.items():
        text = text.replace(k, v)
    return text.encode('latin-1', 'replace').decode('latin-1')

def save_pdf(layout: list) -> str:
    """
    Compiles the full comic into a multi-page PDF file using FPDF.
    
    Args:
        layout (list): List of panel dictionaries.
        
    Returns:
        str: Relative path to the exported PDF.
    """
    pdf = ComicPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.set_margins(left=15, top=18, right=15)
    
    for panel in layout:
        pdf.add_page()
        
        panel_num = panel.get("panel", 1)
        panel_title = panel.get("title", f"Panel {panel_num}")
        image_path = panel.get("image_path", "")
        story_text = panel.get("text", "")
        scene_desc = panel.get("scene_description", "")

        # Reset X to left margin
        pdf.set_x(pdf.l_margin)

        # Panel Title Banner
        pdf.set_font("Helvetica", "B", 15)
        pdf.set_text_color(30, 41, 59)
        safe_title = clean_for_pdf(f"Panel {panel_num}: {panel_title}")
        pdf.cell(pdf.epw, 10, safe_title, align="C", new_x="LMARGIN", new_y="NEXT")
        pdf.ln(2)

        # Image placement
        img_w = 145
        img_h = 92
        x_centered = (pdf.w - img_w) / 2
        y_pos = pdf.get_y()

        if image_path and os.path.exists(image_path):
            try:
                # Border around image
                pdf.set_draw_color(99, 102, 241)
                pdf.set_line_width(0.8)
                pdf.rect(x_centered - 1, y_pos - 1, img_w + 2, img_h + 2)
                pdf.image(image_path, x=x_centered, y=y_pos, w=img_w, h=img_h)
                pdf.set_y(y_pos + img_h + 6)
            except Exception as e:
                pdf.set_font("Helvetica", "I", 10)
                pdf.set_text_color(220, 38, 38)
                pdf.cell(pdf.epw, 10, clean_for_pdf(f"[Illustration: {image_path}]"), align="C", new_x="LMARGIN", new_y="NEXT")
        else:
            pdf.set_font("Helvetica", "I", 10)
            pdf.set_text_color(150, 150, 150)
            pdf.cell(pdf.epw, 10, clean_for_pdf(f"[Illustration: {image_path}]"), align="C", new_x="LMARGIN", new_y="NEXT")

        # Scene description (in italics)
        pdf.set_x(pdf.l_margin)
        if scene_desc:
            pdf.set_font("Helvetica", "I", 9.5)
            pdf.set_text_color(75, 85, 99)
            pdf.multi_cell(pdf.epw, 5.5, clean_for_pdf(f"Scene Atmosphere: {scene_desc}"), new_x="LMARGIN", new_y="NEXT")
            pdf.ln(2)

        # Story narration & dialogue
        pdf.set_font("Helvetica", "", 10)
        pdf.set_text_color(15, 23, 42)
        
        # Clean lines
        story_lines = story_text.splitlines()
        for line in story_lines:
            line_str = line.strip()
            if not line_str:
                continue
            pdf.set_x(pdf.l_margin)
            if line_str.startswith("**CAPTION:**") or line_str.startswith("CAPTION:"):
                pdf.set_font("Helvetica", "B", 9.5)
                pdf.set_text_color(180, 83, 9) # Amber
                pdf.multi_cell(pdf.epw, 5.5, clean_for_pdf(line_str), new_x="LMARGIN", new_y="NEXT")
            elif line_str.startswith("**DIALOGUE:**") or line_str.startswith("DIALOGUE:"):
                pdf.set_font("Helvetica", "B", 9.5)
                pdf.set_text_color(37, 99, 235) # Blue
                pdf.multi_cell(pdf.epw, 5.5, clean_for_pdf(line_str), new_x="LMARGIN", new_y="NEXT")
            elif line_str.startswith("**NARRATION:**") or line_str.startswith("NARRATION:"):
                pdf.set_font("Helvetica", "", 9.5)
                pdf.set_text_color(30, 41, 59)
                pdf.multi_cell(pdf.epw, 5.5, clean_for_pdf(line_str), new_x="LMARGIN", new_y="NEXT")
            else:
                pdf.set_font("Helvetica", "", 9.5)
                pdf.set_text_color(30, 41, 59)
                pdf.multi_cell(pdf.epw, 5.5, clean_for_pdf(line_str), new_x="LMARGIN", new_y="NEXT")
            pdf.ln(1)

    # Save timestamped PDF
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"comic_{timestamp}.pdf"
    pdf_path = os.path.join(EXPORT_FOLDER, filename)
    pdf.output(pdf_path)
    
    return pdf_path.replace("\\", "/")
