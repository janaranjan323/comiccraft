import os
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv

load_dotenv()

# Ensure directories exist
for folder in ["templates", "static", "static/panels", "static/exports", "static/fonts", "static/css", "static/js"]:
    os.makedirs(folder, exist_ok=True)

from app.routes import router

app = FastAPI(
    title="ComicCraft - AI Comic Story Creator",
    description="An AI-powered web app combining Google Gemini Models & Stable Diffusion to create full comic strips and exportable PDFs.",
    version="1.0.0"
)

# Mount static folder
app.mount("/static", StaticFiles(directory="static"), name="static")

# Include application routes
app.include_router(router)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
