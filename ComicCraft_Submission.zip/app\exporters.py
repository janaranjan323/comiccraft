import os
from datetime import datetime
from fpdf import FPDF
from fpdf.enums import XPos, YPos

EXPORT_FOLDER = os.path.join("static", "exports")
os.makedirs(EXPORT_FOLDER, exist_ok=True)

class ComicPDF(FPDF):
    def header(self):
        self.set_font("Helvetica", "B", 10)
        self.set_text_color(120, 120, 140)
        self.cell(0, 8, "ComicCraft - AI Generated Comic", align="R", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        self.ln(4)

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "I", 8)
        self.set_text_color(150, 150, 150)
        self.cell(0, 10, f"Page {self.page_no()}", align="C")

def sanitize_pdf_text(text: str) -> str:
    """Replaces Unicode characters not supported by standard latin1 fonts with readable equivalents."""
    replacements = {
        '“': '"', '”': '"', '‘': "'", '’': "'", '—': '-', '–': '-', '…': '...',
        '•': '*', '★': '*', '⚡': '[zap]', '🔥': '', '✨': ''
    }
    for orig, rep in replacements.items():
        text = text.replace(orig, rep)
    return text.encode('latin-1', 'replace').decode('latin-1')

def save_pdf(layout: list) -> str:
    """
    Compiles the full comic layout into a multi-page PDF document.

    Args:
        layout (list): List of panel dicts containing panel, title, image_path, text, scene_description.

    Returns:
        str: Relative web path to the saved PDF file.
    """
    pdf = ComicPDF()
    pdf.set_auto_page_break(auto=True, margin=15)

    for panel in layout:
        pdf.add_page()

        # Panel Title
        title = sanitize_pdf_text(str(panel.get("title", f"Panel {panel.get('panel', 1)}")))
        pdf.set_font("Helvetica", "B", 16)
        pdf.set_text_color(30, 41, 59)
        pdf.cell(0, 10, title, align="C", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.ln(2)

        # Image placement
        image_path = panel.get("image_path", "")
        if image_path.startswith("/") or image_path.startswith("\\"):
            system_img_path = image_path.lstrip("/\\")
        else:
            system_img_path = image_path

        y_image = 30
        image_height = 95
        page_width = pdf.w - 20

        if os.path.exists(system_img_path):
            try:
                pdf.image(system_img_path, x=10, y=y_image, w=page_width, h=image_height)
            except Exception as e:
                print(f"[WARN] PDF image embedding error: {e}")
                pdf.set_xy(10, y_image + 20)
                pdf.set_font("Helvetica", "I", 12)
                pdf.cell(0, 10, f"[Panel Image: {image_path}]", align="C", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        else:
            pdf.set_xy(10, y_image + 20)
            pdf.set_font("Helvetica", "I", 12)
            pdf.cell(0, 10, f"[Image not found at {system_img_path}]", align="C", new_x=XPos.LMARGIN, new_y=YPos.NEXT)

        # Text placement below image
        pdf.set_y(y_image + image_height + 8)

        # Scene description (in italics)
        scene_desc = panel.get("scene_description", "")
        if scene_desc:
            pdf.set_font("Helvetica", "I", 10)
            pdf.set_text_color(100, 116, 139)
            pdf.multi_cell(0, 6, sanitize_pdf_text(f"Setting: {scene_desc}"))
            pdf.ln(2)

        # Narration and Dialogue Text
        story_text = panel.get("text", "")
        if story_text:
            pdf.set_font("Helvetica", "", 11)
            pdf.set_text_color(15, 23, 42)
            
            for line in story_text.splitlines():
                line = line.strip()
                if not line:
                    continue
                if line.startswith("**CAPTION:**") or line.startswith("CAPTION:"):
                    pdf.set_font("Helvetica", "B", 10)
                    pdf.set_text_color(79, 70, 229)
                    pdf.multi_cell(0, 6, sanitize_pdf_text(line.replace("**", "")))
                elif line.startswith("**NARRATION:**") or line.startswith("NARRATION:"):
                    pdf.set_font("Helvetica", "", 11)
                    pdf.set_text_color(30, 41, 59)
                    pdf.multi_cell(0, 6, sanitize_pdf_text(line.replace("**", "")))
                elif line.startswith("**DIALOGUE:**") or line.startswith("DIALOGUE:") or '"' in line:
                    pdf.set_font("Helvetica", "BI", 11)
                    pdf.set_text_color(190, 24, 93)
                    pdf.multi_cell(0, 6, sanitize_pdf_text(line.replace("**", "")))
                else:
                    pdf.set_font("Helvetica", "", 11)
                    pdf.set_text_color(30, 41, 59)
                    pdf.multi_cell(0, 6, sanitize_pdf_text(line.replace("**", "")))
                pdf.ln(1)

    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    filename = f"comic_{timestamp}.pdf"
    pdf_path = os.path.join(EXPORT_FOLDER, filename)
    pdf.output(pdf_path)

    web_pdf_path = f"static/exports/{filename}".replace("\\", "/")
    return web_pdf_path
