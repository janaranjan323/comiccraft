import os
import re
import math
import hashlib
import urllib.parse
from PIL import Image, ImageDraw, ImageFont
import requests

PANELS_DIR = os.path.join("static", "panels")
os.makedirs(PANELS_DIR, exist_ok=True)

def sanitize_filename(prompt: str) -> str:
    """Sanitizes the prompt into a safe, unique filename."""
    clean = re.sub(r'[^a-zA-Z0-9_\- ]', '', prompt)
    clean = clean.strip().replace(' ', '_')[:30]
    hash_str = hashlib.md5(prompt.encode('utf-8')).hexdigest()[:8]
    if not clean:
        clean = "comic_panel"
    return f"{clean}_{hash_str}.png"

def create_stylized_comic_art(prompt: str, output_path: str, width: int = 768, height: int = 512):
    """
    Creates a gorgeous comic-book style illustration with dynamic gradients,
    halftone comic dots, atmospheric elements, action bursts, and styled text.
    """
    img = Image.new("RGBA", (width, height), (20, 24, 39, 255))
    draw = ImageDraw.Draw(img)

    prompt_l = prompt.lower()
    
    # Choose color palette based on prompt keywords
    if any(w in prompt_l for w in ["forest", "nature", "woods", "tree", "enchanted"]):
        c1, c2, c3 = (15, 37, 28), (28, 90, 60), (74, 222, 128)
    elif any(w in prompt_l for w in ["space", "galaxy", "star", "cosmic", "sci-fi"]):
        c1, c2, c3 = (10, 10, 35), (67, 24, 114), (168, 85, 247)
    elif any(w in prompt_l for w in ["fire", "action", "battle", "fight", "sunset", "red"]):
        c1, c2, c3 = (45, 10, 10), (185, 28, 28), (251, 146, 60)
    elif any(w in prompt_l for w in ["ocean", "water", "sea", "cyberpunk", "rain"]):
        c1, c2, c3 = (8, 28, 48), (2, 132, 199), (56, 189, 248)
    elif any(w in prompt_l for w in ["dark", "mystery", "noir", "shadow", "night"]):
        c1, c2, c3 = (15, 15, 20), (55, 65, 81), (156, 163, 175)
    else:
        c1, c2, c3 = (30, 27, 75), (99, 102, 241), (236, 72, 153)

    # Draw vertical smooth gradient background
    for y in range(height):
        t = y / height
        if t < 0.5:
            factor = t * 2.0
            r = int(c1[0] * (1 - factor) + c2[0] * factor)
            g = int(c1[1] * (1 - factor) + c2[1] * factor)
            b = int(c1[2] * (1 - factor) + c2[2] * factor)
        else:
            factor = (t - 0.5) * 2.0
            r = int(c2[0] * (1 - factor) + c3[0] * factor)
            g = int(c2[1] * (1 - factor) + c3[1] * factor)
            b = int(c2[2] * (1 - factor) + c3[2] * factor)
        draw.line([(0, y), (width, y)], fill=(r, g, b, 255))

    # Comic Halftone Dots Effect Overlay
    dot_spacing = 24
    for gx in range(0, width, dot_spacing):
        for gy in range(0, height, dot_spacing):
            dot_rad = int(2 + 3 * (math.sin(gx * 0.02) * math.cos(gy * 0.02) + 1))
            draw.ellipse(
                [(gx - dot_rad, gy - dot_rad), (gx + dot_rad, gy + dot_rad)],
                fill=(255, 255, 255, 20)
            )

    # Dynamic Comic Action Burst Rays
    cx, cy = width // 2, height // 2
    num_rays = 16
    for i in range(num_rays):
        angle = (i / num_rays) * 2 * math.pi
        angle_next = ((i + 0.3) / num_rays) * 2 * math.pi
        r_outer = 600
        x1 = cx + math.cos(angle) * r_outer
        y1 = cy + math.sin(angle) * r_outer
        x2 = cx + math.cos(angle_next) * r_outer
        y2 = cy + math.sin(angle_next) * r_outer
        draw.polygon([(cx, cy), (x1, y1), (x2, y2)], fill=(255, 255, 255, 12))

    # Center Heroic Silhouette or Graphic Element
    draw.ellipse([(cx - 140, cy - 140), (cx + 140, cy + 140)], fill=(255, 255, 255, 30), outline=(255, 255, 255, 120), width=3)
    draw.ellipse([(cx - 100, cy - 100), (cx + 100, cy + 100)], fill=(15, 23, 42, 220), outline=c3 + (200,), width=2)
    
    # Action Sound FX Bubble / Badge
    draw.polygon([
        (cx - 90, cy - 30), (cx - 50, cy - 60), (cx, cy - 45), (cx + 50, cy - 65),
        (cx + 90, cy - 30), (cx + 70, cy + 15), (cx + 85, cy + 55), (cx + 35, cy + 45),
        (cx, cy + 65), (cx - 40, cy + 40), (cx - 85, cy + 50), (cx - 65, cy + 10)
    ], fill=(245, 158, 11, 230), outline=(255, 255, 255, 255), width=2)

    # Comic Border (Inner panel border)
    draw.rectangle([(12, 12), (width - 13, height - 13)], outline=(255, 255, 255, 180), width=3)
    draw.rectangle([(16, 16), (width - 17, height - 17)], outline=(0, 0, 0, 100), width=1)

    # Add Text Prompt Badge at bottom
    clean_label = prompt.strip()[:65]
    if len(prompt.strip()) > 65:
        clean_label += "..."
    
    draw.rectangle([(20, height - 55), (width - 20, height - 20)], fill=(0, 0, 0, 190), outline=c3 + (150,), width=1)
    
    try:
        font = ImageFont.truetype("arial.ttf", 16)
        title_font = ImageFont.truetype("arialbd.ttf", 22)
    except Exception:
        font = ImageFont.load_default()
        title_font = font

    draw.text((cx, cy - 6), "COMICCRAFT", fill=(255, 255, 255, 255), anchor="mm", font=title_font)
    draw.text((cx, height - 38), clean_label, fill=(255, 255, 255, 230), anchor="mm", font=font)

    # Convert to RGB and save
    rgb_img = img.convert("RGB")
    rgb_img.save(output_path, quality=95)
    return output_path

def generate_image(prompt: str, filename: str = None) -> str:
    """
    Generates a comic-style image based on the provided prompt using AI models
    or high-quality fallback synthesis and saves it to static/panels.
    
    Args:
        prompt (str): Image description prompt.
        filename (str, optional): Target filename.
        
    Returns:
        str: Relative file path to the saved image (e.g. static/panels/xyz.png).
    """
    if not filename:
        filename = sanitize_filename(prompt)
        
    path = os.path.join(PANELS_DIR, filename)
    
    # If image already exists, return its path
    if os.path.exists(path) and os.path.getsize(path) > 1000:
        return path.replace("\\", "/")

    # Check for Hugging Face Inference API
    hf_token = os.getenv("HF_API_KEY")
    if hf_token and not hf_token.startswith("your_"):
        try:
            api_url = "https://api-inference.huggingface.co/models/runwayml/stable-diffusion-v1-5"
            headers = {"Authorization": f"Bearer {hf_token}"}
            comic_prompt = f"comic book art style, graphic novel, highly detailed, vibrant colors, 4k: {prompt}"
            response = requests.post(api_url, headers=headers, json={"inputs": comic_prompt}, timeout=25)
            if response.status_code == 200:
                with open(path, "wb") as f:
                    f.write(response.content)
                print(f"[HuggingFace SD] Generated image saved to {path}")
                return path.replace("\\", "/")
        except Exception as e:
            print(f"[HuggingFace SD Error]: {e}")

    # Try fast high-resolution online AI image generation (Pollinations AI)
    try:
        encoded_prompt = urllib.parse.quote(f"comic book panel art, graphic novel illustration, vibrant dynamic comic, {prompt}")
        poll_url = f"https://image.pollinations.ai/prompt/{encoded_prompt}?width=768&height=512&nologo=true&seed={abs(hash(prompt)) % 100000}"
        resp = requests.get(poll_url, timeout=12)
        if resp.status_code == 200 and len(resp.content) > 5000:
            with open(path, "wb") as f:
                f.write(resp.content)
            print(f"[AI Image Service] Successfully fetched AI comic panel: {path}")
            return path.replace("\\", "/")
    except Exception as e:
        print(f"[AI Image Fetch Notice]: {e}")

    # Fallback to rich stylized comic graphic generation
    create_stylized_comic_art(prompt, path)
    print(f"[Comic Art Engine] Created stylized comic illustration: {path}")
    return path.replace("\\", "/")
