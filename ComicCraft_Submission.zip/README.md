# 💥 ComicCraft - AI Comic Story Creator using Gemini Models

ComicCraft is a full-stack web application that uses Artificial Intelligence to generate personalized comic book stories, character dialogues, and vivid panel illustrations based on user prompts.

Built with **FastAPI**, integrated with **Google's Gemini AI models** (Gemini Flash & Gemini Pro) and **Stable Diffusion**, ComicCraft streamlines the creative comic storytelling process automatically into interactive previews and exportable PDFs.

---

## 🌟 Features

- **Dual-Gemini Pipeline**:
  - **Gemini Flash (`gemini-1.5-flash`)**: Rapid generation of structured 5-panel comic outline and image generation prompts.
  - **Gemini Pro (`gemini-1.5-pro`)**: Deep creative narrative generation with captions, atmospheric setting notes, and character dialogues.
- **AI Panel Illustrations**:
  - Comic-style image generation via **Stable Diffusion** / Hugging Face Diffusers & Pollinations with smart fallback.
- **Dynamic Layout Assembly**:
  - Assembles images, titles, scene descriptions, and dialogue bubbles seamlessly.
- **Automated PDF Compilation**:
  - Formats panels and narration into printable multi-page PDFs using **FPDF**.
- **Interactive Web Interface**:
  - Modern comic book aesthetic, instant story starter presets, live generation status, and export confirmation.
- **RESTful API**:
  - `/generate-comic/json` JSON endpoint for external apps, mobile clients, and automation.

---

## 🏗️ Technical Architecture

```
User (Browser / API Client)
       │
       ▼
 FastAPI Backend (app/main.py & app/routes.py)
       │
 ┌─────┴───────────────────────────────────────────────────────┐
 │                                                             │
 │  1. Gemini Flash (app/gemini_flash.py) ➔ 5-Panel Outline    │
 │  2. Gemini Pro (app/gemini_pro.py)     ➔ Comic Narration    │
 │  3. Stable Diffusion (image_generator) ➔ Panel Artwork      │
 │  4. Layout Builder (layout_builder.py) ➔ Panel Structure    │
 │  5. PDF Exporter (exporters.py)        ➔ Multi-Page PDF     │
 │                                                             │
 └─────┬───────────────────────────────────────────────────────┘
       │
       ▼
 Jinja2 Templates (index.html, comic_preview.html, export_success.html)
```

---

## 📂 Project Directory Structure

```
Comic craft/
├── app/
│   ├── __init__.py
│   ├── main.py              # FastAPI application entry point
│   ├── routes.py            # API routes and web controllers
│   ├── gemini_flash.py      # 5-panel structured outline generation
│   ├── gemini_pro.py        # Narration and character dialogue generation
│   ├── image_generator.py   # Stable Diffusion comic panel illustration
│   ├── layout_builder.py    # Layout organizer for panels and story
│   └── exporters.py         # Multi-page PDF generation via FPDF
├── templates/
│   ├── index.html           # Comic creation input form
│   ├── comic_preview.html   # Full comic preview with panels
│   └── export_success.html  # Export confirmation page
├── static/
│   ├── css/
│   │   └── style.css        # Comic-book modern design system
│   ├── panels/              # Generated comic illustrations
│   ├── exports/             # Exported PDF comic files
│   └── images/              # Assets & background visuals
├── .env                     # Environment variables (API keys)
├── .env.example
├── requirements.txt         # Python dependencies
└── README.md
```

---

## 🚀 Setup & Execution Guide

### 1. Set Up Virtual Environment

```powershell
python -m venv comiccraft-env
comiccraft-env\Scripts\activate
```

### 2. Install Dependencies

```powershell
pip install -r requirements.txt
```

### 3. Configure API Keys in `.env`

Create a `.env` file (or update the existing one):
```env
GEMINI_API_KEY=your_google_gemini_api_key
HF_API_KEY=your_huggingface_token
```
*(Note: ComicCraft also contains robust dynamic fallbacks so it operates gracefully even when keys are being configured!)*

### 4. Run the Application

```powershell
uvicorn app.main:app --reload
```

- **Web App**: Visit `http://127.0.0.1:8000`
- **Swagger API Docs**: Visit `http://127.0.0.1:8000/docs`

---

## 📡 API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/` | Loads the ComicCraft creation form |
| `POST` | `/generate` | Form-based comic creation and preview rendering |
| `POST` | `/generate-comic/json` | JSON API endpoint returning layout data and PDF path |
| `GET` | `/export-success` | Renders the comic export success confirmation page |
| `GET` | `/download-file` | Direct download attachment for the generated PDF |
| `GET` | `/test-image` | Utility endpoint to test image generation directly |
