import os
import traceback
from fastapi import APIRouter, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

from app.gemini_flash import generate_outline
from app.gemini_pro import generate_story
from app.image_generator import generate_image
from app.layout_builder import build_comic_layout
from app.exporters import save_pdf

router = APIRouter()
templates = Jinja2Templates(directory="templates")

class PromptRequest(BaseModel):
    prompt: str = Field(..., description="Main comic story idea")
    character_name: str = Field(default="Hero", description="Character name")
    setting: str = Field(default="Enchanted Forest", description="Setting location")
    tone: str = Field(default="Dramatic", description="Tone of the story")
    style: str = Field(default="Comic Book", description="Visual art style")

@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """Loads the ComicCraft homepage form."""
    return templates.TemplateResponse(
        request,
        "index.html",
        {"request": request}
    )

@router.post("/generate", response_class=HTMLResponse)
async def generate_comic(
    request: Request,
    prompt: str = Form(...),
    character_name: str = Form("Hero"),
    setting: str = Form("Enchanted Forest"),
    tone: str = Form("Dramatic"),
    style: str = Form("Comic Book"),
):
    """Handles HTML form submission, executes AI generation pipeline, and renders comic preview."""
    try:
        # Combine user input into a single rich prompt
        full_prompt = (
            f"{prompt}\n"
            f"The main character is {character_name}.\n"
            f"The setting is a {setting}.\n"
            f"The tone is {tone}. The art style is {style}."
        )

        # Step 1: Generate panel outline using Gemini Flash
        outline = generate_outline(full_prompt)
        if not isinstance(outline, list) or not all("image_prompt" in panel for panel in outline):
            raise ValueError("Invalid outline structure from Gemini response.")

        # Step 2: Generate detailed narration and dialogues using Gemini Pro
        full_story = generate_story(outline)

        # Step 3: Generate images for each panel
        images = [generate_image(f"{panel['image_prompt']}, {style} style") for panel in outline]

        # Step 4: Build structured comic layout
        layout = build_comic_layout(images, full_story, outline)

        # Step 5: Export to PDF
        pdf_path = save_pdf(layout)
        web_pdf_path = "/" + pdf_path.replace("\\", "/")

        return templates.TemplateResponse(
            request,
            "comic_preview.html",
            {
                "request": request,
                "layout": layout,
                "pdf_path": web_pdf_path,
                "story_prompt": prompt,
                "character_name": character_name,
                "setting": setting,
                "tone": tone,
                "style": style
            }
        )

    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/generate-comic/json")
async def generate_comic_json(payload: PromptRequest):
    """API endpoint to generate comics from raw JSON payloads."""
    try:
        full_prompt = (
            f"{payload.prompt}\n"
            f"The main character is {payload.character_name}.\n"
            f"The setting is a {payload.setting}.\n"
            f"The tone is {payload.tone}. The art style is {payload.style}."
        )

        outline = generate_outline(full_prompt)
        full_story = generate_story(outline)
        images = [generate_image(f"{panel['image_prompt']}, {payload.style} style") for panel in outline]
        layout = build_comic_layout(images, full_story, outline)
        pdf_path = save_pdf(layout)
        web_pdf_path = "/" + pdf_path.replace("\\", "/")

        return JSONResponse({
            "status": "success",
            "pdf_path": web_pdf_path,
            "layout": layout
        })
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/export-success", response_class=HTMLResponse)
async def export_success(request: Request, pdf_path: str = ""):
    """Renders the export success confirmation page."""
    return templates.TemplateResponse(
        request,
        "export_success.html",
        {"request": request, "pdf_path": pdf_path}
    )

@router.get("/test-image")
async def test_image(prompt: str = "A futuristic city at sunset, sci-fi, cinematic, artstation"):
    """Developer utility route to test image generation functionality separately."""
    try:
        image_path = generate_image(prompt)
        return {
            "message": "Image generated successfully",
            "path": "/" + image_path.replace("\\", "/")
        }
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/download/{filename}")
async def download_file(filename: str):
    """Direct download handler for exported PDF files."""
    file_path = os.path.join("static", "exports", filename)
    if os.path.exists(file_path):
        return FileResponse(file_path, media_type='application/pdf', filename=filename)
    raise HTTPException(status_code=404, detail="File not found")
