import os
import re
import time
import urllib.parse
import requests
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont
from dotenv import load_dotenv

load_dotenv()

HF_API_KEY = os.getenv("HF_API_KEY")
PANELS_DIR = os.path.join("static", "panels")
os.makedirs(PANELS_DIR, exist_ok=True)

def sanitize_filename(prompt: str) -> str:
    """Sanitizes the prompt into a safe, valid filename."""
    # Strip invalid filesystem characters and truncate
    clean = re.sub(r'[^a-zA-Z0-9_\- ]', '', prompt)
    clean = clean.strip().replace(' ', '_')
    if len(clean) > 35:
        clean = clean[:35]
    timestamp = int(time.time() * 1000) % 1000000
    return f"{clean}_{timestamp}.png" if clean else f"panel_{timestamp}.png"

def create_fallback_comic_image(prompt: str, output_path: str) -> str:
    """Creates a stylized comic placeholder image using Pillow if online image generation is unavailable."""
    width, height = 768, 512
    # Generate pleasant color gradient based on prompt hash
    h = sum(ord(c) for c in prompt)
    r1, g1, b1 = (h * 37) % 180 + 30, (h * 53) % 180 + 30, (h * 71) % 180 + 50
    r2, g2, b2 = (r1 + 60) % 255, (g1 + 80) % 255, (b1 + 90) % 255

    image = Image.new("RGB", (width, height), color=(20, 24, 33))
    draw = ImageDraw.Draw(image)

    # Draw colorful background gradient
    for y in range(height):
        ratio = y / height
        r = int(r1 * (1 - ratio) + r2 * ratio)
        g = int(g1 * (1 - ratio) + g2 * ratio)
        b = int(b1 * (1 - ratio) + b2 * ratio)
        draw.line([(0, y), (width, y)], fill=(r, g, b))

    # Add halftone comic dot pattern overlay
    for x in range(0, width, 18):
        for y in range(0, height, 18):
            draw.ellipse([x, y, x + 3, y + 3], fill=(255, 255, 255, 60))

    # Draw stylized comic frame border
    border_width = 8
    draw.rectangle([border_width, border_width, width - border_width, height - border_width], outline=(255, 255, 255), width=border_width)
    draw.rectangle([border_width + 4, border_width + 4, width - border_width - 4, height - border_width - 4], outline=(15, 15, 25), width=2)

    # Comic speech bubble / caption block
    caption_box = [40, height - 130, width - 40, height - 30]
    draw.rectangle(caption_box, fill=(255, 255, 240), outline=(20, 20, 30), width=4)

    # Draw prompt text inside caption
    wrapped_prompt = prompt if len(prompt) < 80 else prompt[:77] + "..."
    draw.text((60, height - 105), "⚡ COMIC ILLUSTRATION", fill=(200, 30, 30))
    draw.text((60, height - 75), wrapped_prompt, fill=(20, 20, 20))

    image.save(output_path, "PNG")
    return output_path

def generate_image_huggingface(prompt: str, output_path: str) -> bool:
    """Generates image using Hugging Face Inference API if HF_API_KEY is available."""
    if not HF_API_KEY or HF_API_KEY == "your-huggingface-api-key-here":
        return False
    try:
        API_URL = "https://api-inference.huggingface.co/models/runwayml/stable-diffusion-v1-5"
        headers = {"Authorization": f"Bearer {HF_API_KEY}"}
        payload = {"inputs": f"comic book art style, graphic novel, highly detailed, {prompt}"}
        response = requests.post(API_URL, headers=headers, json=payload, timeout=25)
        if response.status_code == 200 and "image" in response.headers.get("content-type", ""):
            img = Image.open(BytesIO(response.content))
            img.save(output_path, "PNG")
            return True
    except Exception as e:
        print(f"⚠️ Hugging Face image generation failed: {e}")
    return False

def generate_image_pollinations(prompt: str, output_path: str) -> bool:
    """Generates high quality AI comic illustration using Pollinations API without requiring API key."""
    try:
        enhanced_prompt = f"comic book illustration, vivid colors, detailed line art, graphic novel panel: {prompt}"
        encoded_prompt = urllib.parse.quote(enhanced_prompt)
        url = f"https://image.pollinations.ai/prompt/{encoded_prompt}?width=768&height=512&seed={int(time.time() * 1000) % 99999}&nologo=true&model=flux"
        response = requests.get(url, timeout=15)
        if response.status_code == 200 and len(response.content) > 1000:
            img = Image.open(BytesIO(response.content))
            img.save(output_path, "PNG")
            return True
    except Exception as e:
        print(f"⚠️ Pollinations image generation failed: {e}")
    return False

def generate_image(prompt: str, filename: str = None) -> str:
    """
    Generates a comic-style image based on the provided prompt and saves to static/panels/.

    Args:
        prompt (str): Image generation prompt.
        filename (str, optional): Target filename. If None, generated from prompt.

    Returns:
        str: Relative web path to the saved image (e.g., 'static/panels/image.png').
    """
    if not filename:
        filename = sanitize_filename(prompt)
    
    file_path = os.path.join(PANELS_DIR, filename)
    web_path = f"static/panels/{filename}".replace("\\", "/")

    # Try Hugging Face API first if configured
    if generate_image_huggingface(prompt, file_path):
        return web_path

    # Try Pollinations AI free provider
    if generate_image_pollinations(prompt, file_path):
        return web_path

    # Fallback to rich stylized comic graphic
    create_fallback_comic_image(prompt, file_path)
    return web_path
